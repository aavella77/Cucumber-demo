$base_url = "http://www.wikipedia.org"

