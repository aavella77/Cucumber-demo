#---
# Excerpted from "The RSpec Book",
# published by The Pragmatic Bookshelf.
# Copyrights apply to this code. It may not be used to create training material, 
# courses, books, articles, and the like. Contact us if you are in doubt.
# We make no guarantees that this code is fit for any purpose. 
# Visit http://www.pragmaticprogrammer.com/titles/achbd for more book information.
#---
def messenger
  @messenger ||= StringIO.new
end

def game
  @game ||= Codebreaker::Game.new(messenger)
end

def messages_should_include(message)
  messenger.string.split("\n").should include(message)
end

Given /^I am not yet playing$/ do
end

Given /^the secret code is (. . . .)$/ do |code|
  game.start(code.split)
end

When /^I guess (. . . .)$/ do |code|
  game.guess(code.split)
end

When /^I start a new game$/ do
  game.start(%w[r g y c])
end

Then /^I should see "([^\"]*)"$/ do |message|
  messages_should_include(message)
end

Then /^the mark should be (.*)$/ do |mark|
  messages_should_include(mark)
end

Given /^6 colors$/ do
end

Given /^4 positions$/ do
end

When /^I play 10,000 games$/ do
  pending
end

Then /^each color should appear between 1500 and 1800 times in each position$/ do
  pending
end

Then /^each color should appear no more than once in each secret code$/ do
  pending
end

