#---
# Excerpted from "The RSpec Book",
# published by The Pragmatic Bookshelf.
# Copyrights apply to this code. It may not be used to create training material, 
# courses, books, articles, and the like. Contact us if you are in doubt.
# We make no guarantees that this code is fit for any purpose. 
# Visit http://www.pragmaticprogrammer.com/titles/achbd for more book information.
#---
require File.join(File.dirname(__FILE__), "..","spec_helper")

module Codebreaker
  describe Generator do
    it "generates a four-element array" do
      generator = Generator.new
      generator.code.length.should == 4
    end
  end
end
