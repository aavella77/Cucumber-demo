#---
# Excerpted from "The RSpec Book",
# published by The Pragmatic Bookshelf.
# Copyrights apply to this code. It may not be used to create training material, 
# courses, books, articles, and the like. Contact us if you are in doubt.
# We make no guarantees that this code is fit for any purpose. 
# Visit http://www.pragmaticprogrammer.com/titles/achbd for more book information.
#---
require File.join(File.dirname(__FILE__), "..","spec_helper")

module Codebreaker
  describe Generator do
    it "generates a four-element array" do
      generator = Generator.new
      generator.code.length.should == 4
    end

    it "only uses the game colors: r, y, g, c, b, and w" do
      generator = Generator.new
      generator.code.each do |color|
        %w[r y g c b w].should include(color)
      end
    end


    it "uses each color no more than once in each code" do
      generator = Generator.new
      20.times do
        generator.code.uniq.length.should == 4
      end
    end

    it "generates a different code each time" do
      generator = Generator.new
      codes = (1..100).collect {generator.code}
      codes.uniq.length.should be >= 95
    end

  end
end
