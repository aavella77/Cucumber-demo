#---
# Excerpted from "The RSpec Book",
# published by The Pragmatic Bookshelf.
# Copyrights apply to this code. It may not be used to create training material, 
# courses, books, articles, and the like. Contact us if you are in doubt.
# We make no guarantees that this code is fit for any purpose. 
# Visit http://www.pragmaticprogrammer.com/titles/achbd for more book information.
#---
module Codebreaker
  class Game
    def initialize(messenger)
      @messenger = messenger
    end

    def start(generator)
      @code = generator.code
      @messenger.puts "Welcome to Codebreaker!"
      @messenger.puts "Enter guess:"
    end

    def guess(guess)
      if guess == ['reveal']
        @messenger.puts @code.join(" ")
      else
        result = [nil,nil,nil,nil]
        guess.each_with_index do |peg, index|
          if @code[index] == peg
            result[index] = "b"
          elsif @code.include?(peg)
            result[@code.index(peg)] ||= "w"
          end
        end
        @messenger.puts result.compact.sort.join
      end
    end

  end
end