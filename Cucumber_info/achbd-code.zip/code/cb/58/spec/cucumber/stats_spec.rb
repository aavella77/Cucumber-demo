#---
# Excerpted from "The RSpec Book",
# published by The Pragmatic Bookshelf.
# Copyrights apply to this code. It may not be used to create training material, 
# courses, books, articles, and the like. Contact us if you are in doubt.
# We make no guarantees that this code is fit for any purpose. 
# Visit http://www.pragmaticprogrammer.com/titles/achbd for more book information.
#---
require File.join(File.dirname(__FILE__),"..","spec_helper") 
require File.join(File.dirname(__FILE__), "..","..","features","support","stats")


module Codebreaker
  describe Stats do
    context "with 1 code with r in position 1" do
      it "returns 1 for count_for('r',1)"
      it "returns 0 for count_for('y',1)"
    end
    context "with 2 codes with r in position 1 twice and y in position 2 once" do
      it "returns 2 for count_for('r',1)"
      it "returns 0 for count_for('y',1)"
      it "returns 1 for count_for('y',2)"
    end
  end
end

